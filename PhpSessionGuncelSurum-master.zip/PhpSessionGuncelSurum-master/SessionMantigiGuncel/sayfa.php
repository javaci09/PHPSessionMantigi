<?php
/*Üye Giriş Formu - İsmail Fedakar*/
$sayfa[1]		=	"giris.php";
$sayfa[2]		=	"girissonuc.php";
$sayfa[3]		=	"cikis.php";
$sayfa[4]		=	"anasayfa.php";
$sayfa[5]		=	"tamam.php";
$sayfa[6]		=	"hata.php";
?>