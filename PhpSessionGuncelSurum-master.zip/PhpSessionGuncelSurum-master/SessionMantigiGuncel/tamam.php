<!--�ye Giri� Formu - �smail Fedakar-->
  <tr>
  <td><table width="360" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="middle">��lem Ba�ar�yla Tamamland�.</td>
      </tr>
    </table></td>
    </tr>
  </table>